import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, Alert, SafeAreaView,
  KeyboardAvoidingView, Platform,
} from 'react-native';

export default function App() {
  const [ekran, setEkran] = useState('ana');
  const [not, setNot] = useState('');

  const handleKaydet = () => {
    if (not.trim() === '') {
      Alert.alert('Uyarı', 'Lütfen bir not girin!');
      return;
    }
    setEkran('detay');
  };

  if (ekran === 'detay') {
    return (
      <SafeAreaView style={detay.container}>
        <View style={detay.inner}>
          <Text style={detay.baslik}>✅ Günün Notun</Text>
          <View style={detay.notKutu}>
            <Text style={detay.notText}>{not}</Text>
          </View>
          <TouchableOpacity
            style={detay.buton}
            onPress={() => { setNot(''); setEkran('ana'); }}
          >
            <Text style={detay.butonText}>Yeni Not Yaz</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={ana.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={ana.inner}
      >
        <Text style={ana.baslik}>📝 Günün Notu</Text>
        <TextInput
          style={ana.input}
          placeholder="Bugün ne yapacaksın?"
          placeholderTextColor="#9E9E9E"
          multiline
          value={not}
          onChangeText={setNot}
        />
        <TouchableOpacity style={ana.buton} onPress={handleKaydet}>
          <Text style={ana.butonText}>Notu Kaydet ve Gör</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const ana = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F4FF' },
  inner: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 32 },
  baslik: { fontSize: 28, fontWeight: 'bold', color: '#1A237E', marginBottom: 32 },
  input: {
    width: '100%', height: 150, backgroundColor: '#FFFFFF',
    padding: 16, fontSize: 16, textAlignVertical: 'top',
    borderRadius: 8, marginBottom: 24, color: '#333',
  },
  buton: {
    width: '100%', height: 56, backgroundColor: '#3F51B5',
    borderRadius: 8, justifyContent: 'center', alignItems: 'center',
  },
  butonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
});

const detay = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A237E' },
  inner: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 32 },
  baslik: { fontSize: 22, color: '#90CAF9', marginBottom: 24 },
  notKutu: { width: '100%', backgroundColor: '#283593', borderRadius: 8, padding: 24, marginBottom: 40 },
  notText: { fontSize: 22, color: '#FFFFFF', fontWeight: 'bold', textAlign: 'center' },
  buton: {
    width: '100%', height: 56, backgroundColor: '#90CAF9',
    borderRadius: 8, justifyContent: 'center', alignItems: 'center',
  },
  butonText: { color: '#1A237E', fontSize: 16, fontWeight: '600' },
});